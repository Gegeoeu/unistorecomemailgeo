<?php
set_time_limit(30);

use PHPMailer\PHPMailer\PHPMailer;

require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/conexao.php';

$mensagem = '';
$tipoMensagem = 'erro';
$metodoRequisicao = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$token = trim($_GET['token'] ?? $_POST['token'] ?? '');
$tokenValido = false;
$resetConcluido = false;

try {
    $tabelaDisponivel = mysqli_query(
        $conexao,
        "CREATE TABLE IF NOT EXISTS password_reset_tokens (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            email_tel VARCHAR(50) NOT NULL,
            token_hash CHAR(64) NOT NULL UNIQUE,
            expires_at DATETIME NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_password_reset_email (email_tel),
            INDEX idx_password_reset_expiration (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
    ) !== false;
} catch (Throwable $erroBanco) {
    $tabelaDisponivel = false;
}

$configuracaoLocal = __DIR__ . '/smtp.local.php';
$smtpLocal = is_file($configuracaoLocal) ? require $configuracaoLocal : [];
$smtpLocal = is_array($smtpLocal) ? $smtpLocal : [];
$smtpHost = getenv('UNISTORE_SMTP_HOST') ?: ($smtpLocal['host'] ?? '');
$smtpUsuario = getenv('UNISTORE_SMTP_USER') ?: ($smtpLocal['username'] ?? '');
$smtpSenha = getenv('UNISTORE_SMTP_PASS') ?: ($smtpLocal['password'] ?? '');
$smtpSenha = preg_replace('/\s+/', '', $smtpSenha);
$smtpRemetente = getenv('UNISTORE_SMTP_FROM') ?: ($smtpLocal['from'] ?? $smtpUsuario);
$smtpPorta = (int) (getenv('UNISTORE_SMTP_PORT') ?: ($smtpLocal['port'] ?? 587));
$smtpCriptografia = getenv('UNISTORE_SMTP_SECURE') ?: ($smtpLocal['secure'] ?? 'tls');
$urlAplicacao = rtrim(getenv('UNISTORE_APP_URL') ?: '', '/');

if ($urlAplicacao === '') {
    $hostRequisicao = $_SERVER['HTTP_HOST'] ?? '';
    $caminhoScript = dirname($_SERVER['SCRIPT_NAME'] ?? '');
    if (preg_match('/\A[a-zA-Z0-9.-]+(?::\d{1,5})?\z/', $hostRequisicao)) {
        $segmentos = explode('/', trim($caminhoScript, '/'));
        $caminhoCodificado = implode('/', array_map(
            static fn($segmento) => rawurlencode(rawurldecode($segmento)),
            $segmentos
        ));
        $protocolo = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
        $urlAplicacao = $protocolo . '://' . $hostRequisicao
            . ($caminhoCodificado !== '' ? '/' . $caminhoCodificado : '');
    }
}

$smtpConfigurado = $smtpHost !== '' && $smtpUsuario !== '' && $smtpSenha !== ''
    && $smtpRemetente !== '' && $urlAplicacao !== ''
    && filter_var($urlAplicacao, FILTER_VALIDATE_URL);

if ($token !== '' && preg_match('/^[a-f0-9]{64}$/', $token) && $tabelaDisponivel) {
    $hashToken = hash('sha256', $token);
    $stmt = mysqli_prepare(
        $conexao,
        'SELECT id FROM password_reset_tokens WHERE token_hash = ? AND expires_at > NOW() LIMIT 1'
    );
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 's', $hashToken);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        $tokenValido = mysqli_stmt_num_rows($stmt) === 1;
        mysqli_stmt_close($stmt);
    }
}

if ($metodoRequisicao === 'POST' && isset($_POST['solicitar'])) {
    $email = strtolower(trim($_POST['email'] ?? ''));

    if (!$tabelaDisponivel) {
        $mensagem = 'Não foi possível acessar o serviço de recuperação. Verifique a conexão com o banco de dados.';
    } elseif (!$smtpConfigurado) {
        $mensagem = 'Informe a senha de aplicativo SMTP em smtp.local.php.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensagem = 'Informe um endereço de e-mail válido.';
    } else {
        $stmt = mysqli_prepare(
            $conexao,
            'SELECT `email/tel`, nome FROM cadastro WHERE LOWER(TRIM(`email/tel`)) = ? LIMIT 1'
        );

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 's', $email);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $emailCadastrado, $nomeUsuario);
            $usuarioEncontrado = mysqli_stmt_fetch($stmt);
            mysqli_stmt_close($stmt);

            if ($usuarioEncontrado) {
                try {
                    $token = bin2hex(random_bytes(32));
                    $hashToken = hash('sha256', $token);
                    $stmt = mysqli_prepare(
                        $conexao,
                        'DELETE FROM password_reset_tokens WHERE email_tel = ?'
                    );
                    mysqli_stmt_bind_param($stmt, 's', $emailCadastrado);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);

                    $stmt = mysqli_prepare(
                        $conexao,
                        'INSERT INTO password_reset_tokens (email_tel, token_hash, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))'
                    );
                    mysqli_stmt_bind_param($stmt, 'ss', $emailCadastrado, $hashToken);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);

                    $linkReset = $urlAplicacao . '/alterarsenha.php?token=' . urlencode($token);
                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->getSMTPInstance()->Timelimit = 10;
                    $mail->Host = $smtpHost;
                    $mail->SMTPAuth = true;
                    $mail->Timeout = 15;
                    $mail->Username = $smtpUsuario;
                    $mail->Password = $smtpSenha;
                    $mail->SMTPSecure = $smtpCriptografia;
                    $mail->Port = $smtpPorta;
                    $mail->CharSet = 'UTF-8';
                    $mail->setFrom($smtpRemetente, 'Unistore');
                    $mail->addAddress($emailCadastrado, $nomeUsuario);
                    $mail->isHTML(true);
                    $mail->Subject = 'Redefinição de senha da Unistore';
                    $mail->Body = '<p>Olá, ' . htmlspecialchars($nomeUsuario, ENT_QUOTES, 'UTF-8')
                        . '.</p><p>Use o link abaixo para criar uma nova senha. Ele expira em 1 hora.</p>'
                        . '<p><a href="' . htmlspecialchars($linkReset, ENT_QUOTES, 'UTF-8')
                        . '">Redefinir minha senha</a></p><p>Se você não solicitou esta alteração, ignore este e-mail.</p>';
                    $mail->AltBody = "Acesse este link para redefinir sua senha (válido por 1 hora): $linkReset";
                    $mail->send();
                } catch (Throwable $erroEmail) {
                    $detalheSmtp = isset($mail) && $mail->ErrorInfo !== ''
                        ? $mail->ErrorInfo
                        : $erroEmail->getMessage();
                    error_log('Falha no envio de recuperação Unistore: ' . $detalheSmtp);
                    $erroSmtp = strtolower($detalheSmtp);
                    if (isset($hashToken)) {
                        $stmt = mysqli_prepare($conexao, 'DELETE FROM password_reset_tokens WHERE token_hash = ?');
                        if ($stmt) {
                            mysqli_stmt_bind_param($stmt, 's', $hashToken);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_close($stmt);
                        }
                    }
                    $token = '';
                    $tokenValido = false;
                    $tipoMensagem = 'erro';
                    if (str_contains($erroSmtp, 'authenticate') || str_contains($erroSmtp, 'credentials')) {
                        $mensagem = 'O Gmail recusou a autenticação SMTP. Confira o endereço e a senha de aplicativo em smtp.local.php.';
                    } elseif (str_contains($erroSmtp, 'timed out') || str_contains($erroSmtp, 'timeout')) {
                        $mensagem = 'O servidor SMTP não respondeu em 10 segundos. Confira sua conexão e tente novamente.';
                    } else {
                        $mensagem = 'Falha no servidor de e-mail: ' . htmlspecialchars(
                            mb_substr($detalheSmtp, 0, 220),
                            ENT_QUOTES,
                            'UTF-8'
                        );
                    }
                }
            }

            if ($mensagem === '') {
                $tipoMensagem = 'sucesso';
                $mensagem = 'Se houver um cadastro com esse e-mail, enviaremos um link para redefinir a senha.';
            }
        } else {
            $mensagem = 'Não foi possível consultar os cadastros neste momento.';
        }
    }
}

if ($metodoRequisicao === 'POST' && isset($_POST['redefinir'])) {
    $senha = $_POST['senha'] ?? '';
    $confirmacao = $_POST['confirmar_senha'] ?? '';

    if (!$tabelaDisponivel) {
        $mensagem = 'Não foi possível acessar o serviço de recuperação. Tente novamente mais tarde.';
    } elseif (!preg_match('/^[a-f0-9]{64}$/', $token)) {
        $mensagem = 'Este link de recuperação é inválido ou expirou.';
    } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/', $senha)) {
        $mensagem = 'A senha deve ter ao menos 8 caracteres, com maiúscula, minúscula, número e símbolo.';
    } elseif ($senha !== $confirmacao) {
        $mensagem = 'As senhas informadas não são iguais.';
    } else {
        try {
            mysqli_begin_transaction($conexao);
            $hashToken = hash('sha256', $token);
            $stmt = mysqli_prepare(
                $conexao,
                'SELECT email_tel FROM password_reset_tokens WHERE token_hash = ? AND expires_at > NOW() LIMIT 1 FOR UPDATE'
            );
            mysqli_stmt_bind_param($stmt, 's', $hashToken);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_bind_result($stmt, $emailCadastrado);
            $tokenEncontrado = mysqli_stmt_fetch($stmt);
            mysqli_stmt_close($stmt);

            if (!$tokenEncontrado) {
                throw new RuntimeException('Token inválido ou expirado.');
            }

            $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
            $stmt = mysqli_prepare($conexao, 'UPDATE cadastro SET senha = ? WHERE `email/tel` = ?');
            mysqli_stmt_bind_param($stmt, 'ss', $senhaHash, $emailCadastrado);
            mysqli_stmt_execute($stmt);
            $senhaAtualizada = mysqli_stmt_affected_rows($stmt) === 1;
            mysqli_stmt_close($stmt);

            if (!$senhaAtualizada) {
                throw new RuntimeException('O cadastro não foi atualizado.');
            }

            $stmt = mysqli_prepare($conexao, 'DELETE FROM password_reset_tokens WHERE token_hash = ?');
            mysqli_stmt_bind_param($stmt, 's', $hashToken);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            mysqli_commit($conexao);

            $token = '';
            $tokenValido = false;
            $resetConcluido = true;
            $tipoMensagem = 'sucesso';
            $mensagem = 'Senha alterada com sucesso. Agora você já pode entrar com a nova senha.';
        } catch (Throwable $erroReset) {
            mysqli_rollback($conexao);
            $mensagem = $erroReset instanceof RuntimeException
                ? 'Este link de recuperação é inválido ou expirou. Solicite outro link.'
                : 'Não foi possível alterar a senha neste momento. Tente novamente.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar senha | Unistore</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            padding: 24px;
            display: grid;
            place-items: center;
            background: linear-gradient(135deg, #ffe6f2, #ffd6eb);
            color: #51283e;
            font-family: 'Segoe UI', sans-serif;
        }
        .container {
            width: min(440px, 100%);
            padding: 32px;
            border-radius: 16px;
            background: #fff;
            box-shadow: 0 12px 32px rgba(80, 35, 57, .16);
        }
        .logo { display: block; width: min(230px, 100%); height: auto; margin: 0 auto 20px; }
        h1 { margin: 0 0 10px; text-align: center; font-size: 24px; }
        .intro { margin: 0 0 22px; color: #6a4251; text-align: center; line-height: 1.5; }
        label { display: block; margin: 14px 0 6px; font-weight: 600; }
        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #e6bfd1;
            border-radius: 8px;
            font: inherit;
        }
        input:focus { outline: 2px solid #d63384; outline-offset: 1px; }
        button, .botao {
            display: block;
            width: 100%;
            margin-top: 20px;
            padding: 12px 16px;
            border: 0;
            border-radius: 8px;
            background: #b51e68;
            color: #fff;
            font: inherit;
            font-weight: 700;
            text-align: center;
            text-decoration: none;
            cursor: pointer;
        }
        .mensagem { margin: 16px 0 0; padding: 12px; border-radius: 8px; line-height: 1.45; }
        .sucesso { background: #e7f5eb; color: #205b32; }
        .erro { background: #fff0f0; color: #8d2424; }
        .voltar { display: block; margin-top: 18px; color: #8b3a62; text-align: center; }
        @media (max-width: 480px) { .container { padding: 24px; } }
    </style>
</head>
<body>
<main class="container">
    <img src="logo.png" alt="Unistore" class="logo">
    <h1>Recuperação de senha</h1>

    <?php if ($resetConcluido): ?>
        <p class="intro">Sua senha foi atualizada.</p>
    <?php elseif ($token !== '' && $tokenValido): ?>
        <p class="intro">Crie uma nova senha para sua conta.</p>
        <form method="post">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
            <label for="senha">Nova senha</label>
            <input id="senha" type="password" name="senha" autocomplete="new-password" required>
            <label for="confirmar_senha">Confirme a nova senha</label>
            <input id="confirmar_senha" type="password" name="confirmar_senha" autocomplete="new-password" required>
            <button type="submit" name="redefinir">Salvar nova senha</button>
        </form>
    <?php elseif ($token !== ''): ?>
        <p class="intro">O link é inválido ou expirou. Solicite uma nova recuperação.</p>
    <?php else: ?>
        <p class="intro">Informe o e-mail usado no cadastro para receber um link seguro de redefinição.</p>
        <form method="post">
            <label for="email">E-mail</label>
            <input id="email" type="email" name="email" autocomplete="email" required>
            <button type="submit" name="solicitar">Enviar link de recuperação</button>
        </form>
    <?php endif; ?>

    <?php if ($mensagem !== ''): ?>
        <p class="mensagem <?php echo htmlspecialchars($tipoMensagem, ENT_QUOTES, 'UTF-8'); ?>" role="status">
            <?php echo htmlspecialchars($mensagem, ENT_QUOTES, 'UTF-8'); ?>
        </p>
    <?php endif; ?>

    <a class="voltar" href="login.php">Voltar para o login</a>
</main>
</body>
</html>