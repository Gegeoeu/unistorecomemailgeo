<?php
header('Location: ../alterarsenha.php', true, 302);
exit;