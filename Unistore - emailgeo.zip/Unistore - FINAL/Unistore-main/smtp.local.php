<?php
return [
    'host' => 'smtp.gmail.com',
    'username' => 'gegeorodriguessilva@gmail.com',
    'password' => 'kqkkrkbxcsjzgatw',
    'from' => 'gegeorodriguessilva@gmail.com',
    'port' => 465,
    'secure' => 'ssl',
];